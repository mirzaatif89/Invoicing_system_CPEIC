# Institute Accounts API

Express and Prisma backend for the Institute Accounts system.

## Local setup

1. Copy `.env.example` to `.env` and set a private `JWT_SECRET`.
2. Set `DATABASE_URL="file:./data/invoice_app_for_usman.db"`.
3. Install packages with `npm install`.
4. From the repository root, run `npm start`. This creates the SQLite directory, applies committed migrations, and seeds the initial administrator.

The SQLite URL is relative to `prisma/schema.prisma`, so the development database is stored in `backend/prisma/data/`. SQLite needs no service process. The API is available at `http://localhost:4000`; check `GET /api/health`.

Useful commands:

```powershell
npm run prisma:generate
npm run db:deploy
npm run db:seed
npm run build
npm test
```

Prisma enums and JSON fields are retained and validated through the application schema. Existing MySQL data is not imported automatically.
