# Institute Accounts, Payroll & Invoice Management System

Offline-first accounting and invoice management app with a React frontend, Express API, Prisma ORM, and SQLite database.

## Run locally

Install dependencies once:

```powershell
npm install
npm run install:all
```

Set `DATABASE_URL` in `backend/.env` to `file:./data/invoice_app_for_usman.db`, then start the app:

```powershell
npm start
```

The first start creates the SQLite database, applies migrations, and creates the initial administrator if one does not exist. Open http://localhost:5173 and sign in with `admin` / `ChangeMe123!`; change this password after signing in. The development database is stored at `backend/prisma/data/invoice_app_for_usman.db`.

`npm start` starts the database setup, API, and frontend. SQLite runs inside the app as a single file, so no database service needs to be installed or started. Ctrl+C stops the API and frontend.

## Build and tests

```powershell
npm run build
npm test
```

## Portable Windows desktop app

Build a copyable Windows x64 desktop executable with:

```powershell
npm run desktop:package
```

The output is `release/Institute-Accounts-System-Portable.exe`. Copy it to another Windows x64 PC and open it; Node.js and MySQL are not required. The app stores its SQLite database and settings in the current Windows user's AppData folder under `Institute Accounts System Desktop`. Database records persist across restarts and app updates. Use the application's backup feature before moving the database to another computer.

The desktop app starts with `admin` / `ChangeMe123!` if its database has no administrator yet. Change the password after signing in.

## Existing MySQL data

The SQLite switch does not convert or remove the previous MySQL data. The old MySQL files remain in their existing folders and can be migrated separately if needed. The application starts with a new SQLite database unless a migration/import is performed.

## Included modules

- Secure login, user administration, password change, and audit log
- Payee and account-code management
- Invoice entry and editing, cheques, tax handling, and contingent bills
- Purchase-order supply tracking, delivery dates, and deductions
- Budget documents, fiscal-year summaries, and account-wise balances
- Printable reports, PDF layouts, Excel exports, backup and restore
